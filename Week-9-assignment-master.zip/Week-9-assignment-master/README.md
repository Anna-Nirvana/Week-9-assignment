# Week 9

[Data source](https://observablehq.com/@d3/sankey-diagram)

### Requirements

- make a sankey diagram from the data/energy.json
- it should showcase the energy production to energy consumption of UK from left to right.

Check the data source link for reference.